import os
import json
import re
import time
import logging
from openai import OpenAI
import tiktoken
from html import escape
from datetime import datetime, timedelta
import uuid

# Thiết lập logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("remediation.log", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Quản lý rate limit


class RateLimiter:
    def __init__(self, requests_per_minute=15, requests_per_day=150, max_concurrent=5):
        self.requests_per_minute = requests_per_minute
        self.requests_per_day = requests_per_day
        self.max_concurrent = max_concurrent
        self.requests = []
        self.concurrent_requests = 0

    def can_make_request(self):
        now = datetime.now()
        self.requests = [
            req for req in self.requests if now - req < timedelta(minutes=1)]
        self.requests = [
            req for req in self.requests if now - req < timedelta(days=1)]

        if len(self.requests) >= self.requests_per_day:
            logger.warning("Đã đạt giới hạn request hàng ngày")
            return False
        if len([req for req in self.requests if now - req < timedelta(minutes=1)]) >= self.requests_per_minute:
            logger.warning("Đã đạt giới hạn request mỗi phút")
            return False
        if self.concurrent_requests >= self.max_concurrent:
            logger.warning("Đã đạt giới hạn request đồng thời")
            return False
        return True

    def add_request(self):
        self.requests.append(datetime.now())
        self.concurrent_requests += 1

    def complete_request(self):
        self.concurrent_requests -= 1


# Lấy token từ biến môi trường
try:
    token = os.environ["GITHUB_TOKEN"].strip()
except KeyError:
    logger.error("GITHUB_TOKEN không được thiết lập trong biến môi trường")
    raise

endpoint = "https://models.inference.ai.azure.com"

# Khởi tạo client
client = OpenAI(base_url=endpoint, api_key=token)

# Khởi tạo rate limiter
rate_limiter = RateLimiter(requests_per_minute=15,
                           requests_per_day=150, max_concurrent=5)

# Hàm chia nội dung theo token


def split_content_by_tokens(file_path, max_tokens=2000, model="gpt-4o"):
    """Chia nội dung file thành các chunk dựa trên số token."""
    if not os.path.exists(file_path):
        logger.error(f"File không tồn tại: {file_path}")
        raise FileNotFoundError(f"File không tồn tại: {file_path}")

    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read().strip()

    if not content:
        logger.warning("File đầu vào rỗng")
        return []

    encoding = tiktoken.encoding_for_model(model)
    lines = content.splitlines()

    chunks = []
    current_chunk = ""
    current_tokens = 0

    for line in lines:
        line = line.rstrip()
        line_tokens = len(encoding.encode(line + "\n"))
        if current_tokens + line_tokens > max_tokens:
            if current_chunk.strip():
                chunks.append(current_chunk.strip())
            current_chunk = line + "\n"
            current_tokens = line_tokens
        else:
            current_chunk += line + "\n"
            current_tokens += line_tokens

    if current_chunk.strip():
        chunks.append(current_chunk.strip())

    logger.info(f"Đã chia file thành {len(chunks)} chunk")
    return chunks

# Hàm tạo báo cáo remediation cho một chunk


def generate_remediation_chunk(chunk, chunk_index, max_retries=5):
    """Tạo remediation report cho một chunk."""
    logger.info(f"Xử lý chunk {chunk_index + 1}")

    # Hiển thị nội dung chunk để debug
    logger.debug(f"Nội dung chunk {chunk_index + 1}:\n{chunk[:500]}...")

    system_prompt = (
        "You are a cybersecurity analyst tasked with generating a comprehensive remediation plan based on malware analysis logs and vulnerability scan reports.\n\n"
        "You will receive a chunk of a report that may include:\n"
        "- Malware indicators (file paths, IP addresses, domains, registry keys, processes, DLLs, etc.)\n"
        "- Threat classifications (e.g., ransomware, trojan) and behaviors (e.g., persistence, network activity)\n"
        "- Vulnerability details (e.g., CVEs, outdated software versions, solutions from Nessus scans)\n\n"
        "Generate a JSON object representing a remediation plan for the given chunk, with the following structure:\n"
        "{\n"
        "  'malware_info': [\n"
        "    {'name': 'malware name (e.g., TeslaCrypt)', 'type': 'e.g., ransomware, trojan', 'hash': 'file hash (if available)', 'behavior': 'brief description of behaviors (e.g., encrypts files, communicates with C2)'}"
        "  ],\n"
        "  'malware_remediation': [\n"
        "    {'finding': 'specific indicator (e.g., file path, IP)', 'action': 'specific action (e.g., delete file, block IP)'}\n"
        "  ],\n"
        "  'vulnerability_remediation': [\n"
        "    {'cve': 'CVE-ID', 'finding': 'vulnerability details (e.g., outdated software)', 'action': 'specific action (e.g., update to version X)'}\n"
        "  ],\n"
        "  'general_recommendations': [\n"
        "    {'category': 'e.g., system hardening, backup', 'action': 'specific recommendation'}\n"
        "  ]\n"
        "}\n\n"
        "Rules:\n"
        "- For 'malware_info', extract details from the report (e.g., name, type, hash, behaviors). If unavailable, return an empty array.\n"
        "- For malware indicators, provide precise actions (e.g., 'Delete C:\\bad.exe', 'Block IP 8.8.8.8').\n"
        "- For CVEs, include the CVE ID and specific update/patch instructions from the report.\n"
        "- For ransomware (e.g., TeslaCrypt), include actions like isolating the system, avoiding ransom payment, and checking for decryption tools in 'malware_remediation'.\n"
        "- Include general recommendations only if relevant (e.g., system hardening, backups, user training) and base them on the report's context (e.g., ransomware requires backups).\n"
        "- If the chunk lacks specific indicators, CVEs, or context for general recommendations, return empty arrays for those sections.\n"
        "- Prioritize actions: handle active malware first, then vulnerabilities, then general improvements.\n"
        "- Return ONLY the JSON object. Do not include explanations, markdown, or extra text."
    )

    for attempt in range(max_retries):
        if not rate_limiter.can_make_request():
            logger.warning(
                f"Đạt giới hạn rate limit, thử lại sau {2 ** attempt} giây")
            time.sleep(2 ** attempt)
            continue

        try:
            rate_limiter.add_request()
            response = client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {
                        "role": "user",
                        "content": (
                            f"Based on the following portion of the malware analysis and vulnerability report (part {chunk_index + 1}):\n"
                            f"{chunk}\n"
                            "Generate a remediation plan in JSON format as specified."
                        )
                    }
                ],
                max_tokens=1500,
                temperature=0.1
            )

            content = response.choices[0].message.content.strip()
            logger.debug(f"Phản hồi API chunk {chunk_index + 1}:\n{content}")

            # Lưu nội dung để debug
            with open(f"debug_chunk_{chunk_index + 1}.txt", "w", encoding="utf-8") as f:
                f.write(content)

            if not content:
                logger.warning(f"Phản hồi rỗng cho chunk {chunk_index + 1}")
                return {
                    "malware_info": [],
                    "malware_remediation": [],
                    "vulnerability_remediation": [],
                    "general_recommendations": []
                }

            # Loại bỏ markdown
            content = re.sub(r"```(?:json)?\s*(.*?)\s*```",
                             r"\1", content, flags=re.DOTALL)
            content = content.strip()

            # Kiểm tra JSON hợp lệ
            try:
                parsed_json = json.loads(content)
                required_keys = ["malware_info", "malware_remediation",
                                 "vulnerability_remediation", "general_recommendations"]
                if not isinstance(parsed_json, dict) or any(k not in parsed_json for k in required_keys):
                    logger.warning(
                        f"Phản hồi không đúng cấu trúc JSON object: {content[:100]}...")
                    return {
                        "malware_info": [],
                        "malware_remediation": [],
                        "vulnerability_remediation": [],
                        "general_recommendations": []
                    }
                return parsed_json
            except json.JSONDecodeError as e:
                logger.warning(
                    f"Lỗi JSON chunk {chunk_index + 1}, thử {attempt + 1}: {str(e)}")
                if attempt == max_retries - 1:
                    logger.error(
                        f"Không thể parse JSON sau {max_retries} lần thử")
                    return {
                        "malware_info": [],
                        "malware_remediation": [],
                        "vulnerability_remediation": [],
                        "general_recommendations": []
                    }

        except Exception as e:
            logger.error(
                f"Lỗi API chunk {chunk_index + 1}, thử {attempt + 1}: {str(e)}")
            if attempt == max_retries - 1:
                logger.error(f"Thất bại sau {max_retries} lần thử")
                return {
                    "malware_info": [],
                    "malware_remediation": [],
                    "vulnerability_remediation": [],
                    "general_recommendations": []
                }
        finally:
            rate_limiter.complete_request()

        time.sleep(2 ** attempt)

    return {
        "malware_info": [],
        "malware_remediation": [],
        "vulnerability_remediation": [],
        "general_recommendations": []
    }

# Hàm xử lý toàn bộ file


def generate_remediation(file_path):
    """Tạo remediation report từ file báo cáo."""
    try:
        chunks = split_content_by_tokens(file_path)
        if not chunks:
            logger.warning("Không có chunk để xử lý")
            return json.dumps(
                {
                    "malware_info": [],
                    "malware_remediation": [],
                    "vulnerability_remediation": [],
                    "general_recommendations": []
                },
                indent=2,
                ensure_ascii=False
            )

        remediation_plan = {
            "malware_info": [],
            "malware_remediation": [],
            "vulnerability_remediation": [],
            "general_recommendations": []
        }

        for i, chunk in enumerate(chunks):
            chunk_remediation = generate_remediation_chunk(chunk, i)
            remediation_plan["malware_info"].extend(
                chunk_remediation["malware_info"])
            remediation_plan["malware_remediation"].extend(
                chunk_remediation["malware_remediation"])
            remediation_plan["vulnerability_remediation"].extend(
                chunk_remediation["vulnerability_remediation"])
            remediation_plan["general_recommendations"].extend(
                chunk_remediation["general_recommendations"])

        # Loại bỏ trùng lặp
        seen_malware = set()
        unique_malware_info = []
        for item in remediation_plan["malware_info"]:
            identifier = f"{item['name']}:{item['hash']}"
            if identifier not in seen_malware:
                seen_malware.add(identifier)
                unique_malware_info.append(item)
        remediation_plan["malware_info"] = unique_malware_info

        seen_findings = set()
        unique_malware_remediations = []
        for item in remediation_plan["malware_remediation"]:
            finding = item["finding"]
            if finding not in seen_findings:
                seen_findings.add(finding)
                unique_malware_remediations.append(item)
        remediation_plan["malware_remediation"] = unique_malware_remediations

        seen_cves = set()
        unique_vuln_remediations = []
        for item in remediation_plan["vulnerability_remediation"]:
            cve = item["cve"]
            if cve not in seen_cves:
                seen_cves.add(cve)
                unique_vuln_remediations.append(item)
        remediation_plan["vulnerability_remediation"] = unique_vuln_remediations

        seen_recommendations = set()
        unique_general_recommendations = []
        for item in remediation_plan["general_recommendations"]:
            action = item["action"]
            if action not in seen_recommendations:
                seen_recommendations.add(action)
                unique_general_recommendations.append(item)
        remediation_plan["general_recommendations"] = unique_general_recommendations

        result = json.dumps(remediation_plan, indent=2, ensure_ascii=False)
        logger.info("Đã tạo remediation report")
        return result

    except Exception as e:
        logger.error(f"Lỗi tạo report: {str(e)}")
        return json.dumps(
            {
                "malware_info": [],
                "malware_remediation": [],
                "vulnerability_remediation": [],
                "general_recommendations": []
            },
            indent=2,
            ensure_ascii=False
        )

# Hàm tạo HTML từ JSON


def generate_html_report(json_file="remediation_reporta205.json", output_html_file="remediation_reporta205.html"):
    """Tạo file HTML từ JSON report."""
    try:
        with open(json_file, "r", encoding="utf-8") as f:
            report_json = json.load(f)

        html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Remediation Report</title>
    <style>
        body {{
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }}
        h1, h2 {{
            color: #333;
            text-align: center;
        }}
        .report-container {{
            max-width: 1000px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }}
        .section {{
            margin-bottom: 20px;
        }}
        .finding {{
            margin-bottom: 10px;
            padding: 10px;
            border-left: 4px solid #d9534f;
            background-color: #fff5f5;
        }}
        .finding p {{
            margin: 5px 0;
            font-size: 16px;
        }}
    </style>
</head>
<body>
    <div class="report-container">
        <h1>Remediation Report</h1>
        <div class="section">
"""
        for item in report_json["malware_info"]:
            name = escape(item.get("name", ""))
            type_ = escape(item.get("type", ""))
            hash_ = escape(item.get("hash", ""))
            behavior = escape(item.get("behavior", ""))
            html_content += (
                f'            <div class="finding">\n'
                f'                <p><strong>Name:</strong> {name}</p>\n'
                f'                <p><strong>Type:</strong> {type_}</p>\n'
                f'                <p><strong>Hash:</strong> {hash_}</p>\n'
                f'                <p><strong>Behavior:</strong> {behavior}</p>\n'
                f'            </div>\n'
            )
        html_content += """        </div>
        <div class="section">
            <h2>Malware Remediation</h2>
"""
        for item in report_json["malware_remediation"]:
            finding = escape(item.get("finding", ""))
            action = escape(item.get("action", ""))
            html_content += (
                f'            <div class="finding">\n'
                f'                <p><strong>Finding:</strong> {finding}</p>\n'
                f'                <p><strong>Action:</strong> {action}</p>\n'
                f'            </div>\n'
            )
        html_content += """        </div>
        <div class="section">
            <h2>Vulnerability Remediation</h2>
"""
        for item in report_json["vulnerability_remediation"]:
            cve = escape(item.get("cve", ""))
            finding = escape(item.get("finding", ""))
            action = escape(item.get("action", ""))
            html_content += (
                f'            <div class="finding">\n'
                f'                <p><strong>CVE:</strong> {cve}</p>\n'
                f'                <p><strong>Finding:</strong> {finding}</p>\n'
                f'                <p><strong>Action:</strong> {action}</p>\n'
                f'            </div>\n'
            )
        html_content += """        </div>
        <div class="section">
            <h2>General Recommendations</h2>
"""
        for item in report_json["general_recommendations"]:
            category = escape(item.get("category", ""))
            action = escape(item.get("action", ""))
            html_content += (
                f'            <div class="finding">\n'
                f'                <p><strong>Category:</strong> {category}</p>\n'
                f'                <p><strong>Action:</strong> {action}</p>\n'
                f'            </div>\n'
            )
        html_content += """        </div>
    </div>
</body>
</html>"""

        with open(output_html_file, "w", encoding="utf-8") as f:
            f.write(html_content)

        logger.info(f"Đã tạo file HTML: {output_html_file}")
        return output_html_file

    except FileNotFoundError:
        logger.error(f"File JSON không tồn tại: {json_file}")
        raise
    except json.JSONDecodeError:
        logger.error(f"File JSON không hợp lệ: {json_file}")
        raise
    except Exception as e:
        logger.error(f"Lỗi tạo HTML: {str(e)}")
        raise

# Hàm main


def main():
    input_file = "remediationa205.txt"

    try:
        report = generate_remediation(input_file)
        print("\nRemediation Report:")
        print(report)

        with open("remediation_reporta205.json", "w", encoding="utf-8") as f:
            f.write(report)

        html_file = generate_html_report()
        print(f"\nĐã tạo file HTML: {html_file}")

    except Exception as e:
        logger.error(f"Lỗi trong main: {str(e)}")
        raise


if __name__ == "__main__":
    main()
