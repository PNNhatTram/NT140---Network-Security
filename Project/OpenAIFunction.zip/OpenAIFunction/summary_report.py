import pandas as pd
import json
import os

HASH_TYPES = ["md5", "sha1", "sha256",
              "ssdeep", "tlsh", "authentihash", "vhash"]


def write_to_file(text, filename="remediation_input.txt"):
    with open(filename, 'a', encoding='utf-8') as f:
        f.write(text.strip() + "\n\n")


def read_cuckoo(json_file):
    try:
        with open(json_file, 'r', encoding='utf-8') as f:
            json_data = json.load(f)

        info = json_data.get("info", {})
        behavior = json_data.get("behavior", {})
        network = json_data.get("network", {})
        summary = behavior.get("summary", {})

        result = [
            "--- Cuckoo Sandbox Report ---",
            f"Score: {info.get('score', 'N/A')}/10",
            f"Duration: {info.get('duration', 'N/A')}s",
            f"Platform: {info.get('platform', 'N/A')}",
            f"Package: {info.get('package', 'N/A')}",
            f"HTTP Requests: {', '.join([h.get('uri', '') for h in network.get('http', [])[:3]]) or 'None'}",
            f"DNS Requests: {', '.join([d.get('request', '') for d in network.get('dns', [])[:3]]) or 'None'}",
            f"Files Created: {', '.join(summary.get('file_created', [])[:3]) or 'None'}",
            f"Registry Keys Written: {', '.join(summary.get('regkey_written', [])[:3]) or 'None'}",
            f"DLLs Loaded: {', '.join(summary.get('dll_loaded', [])[:3]) or 'None'}"
        ]
        return "\n".join(result)
    except Exception as e:
        return f"Error in read_cuckoo: {str(e)}"


def read_virustotal(json_data):
    try:
        attributes = json_data["data"]["attributes"]

        # 1. Hashes
        hashes = {hash_type: attributes.get(
            hash_type, "N/A") for hash_type in HASH_TYPES}
        hashes_summary = "; ".join(
            f"{key}: {value}" for key, value in hashes.items() if value != "N/A")

        # 2. Malicious Score
        last_analysis_stats = attributes.get("last_analysis_stats", {})
        total = sum(last_analysis_stats.values())
        malicious_score = f"{last_analysis_stats.get('malicious', 0)}/{total}"

        # 3. Behavior Rules
        crowdsourced_ids = attributes.get("crowdsourced_ids_results", [])
        behavior_info = []
        network_ips = set()
        domains = set()
        for res in crowdsourced_ids:
            if "alert_context" in res:
                for context in res["alert_context"]:
                    if "hostname" in context:
                        domains.add(context["hostname"])
                    if "dest_ip" in context:
                        network_ips.add(context["dest_ip"])
            behavior_info.append(res.get("rule_msg", ""))
        behavior_summary = "; ".join(
            behavior_info[:5]) if behavior_info else "None detected"
        network_summary = ", ".join(network_ips) if network_ips else "None"
        domains_summary = ", ".join(domains) if domains else "None"

        # 4. AV Detection Names
        av_detections = attributes.get("last_analysis_results", {})
        engine_hits = [f"{engine}: {result.get('result')}" for engine, result in av_detections.items()
                       if result.get("category") == "malicious"]
        av_summary = "; ".join(engine_hits[:10]) if engine_hits else "None"

        # 5. Threat Classification
        threat_classification = attributes.get(
            "popular_threat_classification", {})
        suggested_threat = threat_classification.get(
            "suggested_threat_label", "Unknown")
        threat_names = [item["value"]
                        for item in threat_classification.get("popular_threat_name", [])]
        threat_categories = [item["value"] for item in threat_classification.get(
            "popular_threat_category", [])]
        malware_summary = ", ".join(
            threat_names) if threat_names else "Unknown"
        category_summary = ", ".join(
            threat_categories) if threat_categories else "Unknown"

        # 6. Tags
        tags = attributes.get("tags", [])
        tags_summary = ", ".join(tags) if tags else "None"

        # 7. YARA Rules
        yara_rules = attributes.get("crowdsourced_yara_results", [])
        yara_summary = "; ".join(y.get("rule_name", "")
                                 for y in yara_rules[:3]) if yara_rules else "None"

        # 8. Reputation
        reputation = attributes.get("reputation", "N/A")

        # 9. Sandbox verdicts
        sandbox_verdicts = attributes.get("sandbox_verdicts", {})
        malware_names = []
        for verdict in sandbox_verdicts.values():
            malware_names.extend(verdict.get("malware_names", []))
        malware_from_sandbox = ", ".join(
            set(malware_names)) if malware_names else "Unknown"

        # 10. Compile Summary Text
        summary_text = (
            f"--- VirusTotal Scan Summary ---\n"
            f"Hashes: {hashes_summary}\n"
            f"Malicious Score: {malicious_score}\n"
            f"Detection Engines: {av_summary}\n"
            f"Behavior Rules Triggered: {behavior_summary}\n"
            f"Network IOCs: IPs - {network_summary}; Domains - {domains_summary}\n"
            f"Threat Classification: {suggested_threat}\n"
            f"Threat Names: {malware_summary}\n"
            f"Categories: {category_summary}\n"
            f"Sandbox Malware Names: {malware_from_sandbox}\n"
            f"YARA Rules: {yara_summary}\n"
            f"Tags: {tags_summary}\n"
            f"Reputation Score: {reputation}"
        )

        return summary_text

    except Exception as e:
        return f"Error extracting JSON data: {str(e)}"


def read_nessus(normal_file, malware_file):
    try:
        # Đọc hai file CSV
        df_normal = pd.read_csv(normal_file)
        df_malware = pd.read_csv(malware_file)

        # Lọc các dòng có giá trị CVE hợp lệ (không trống, không NaN)
        df_normal = df_normal[df_normal['CVE'].notna(
        ) & df_normal['CVE'].str.strip().ne('')]
        df_malware = df_malware[df_malware['CVE'].notna(
        ) & df_malware['CVE'].str.strip().ne('')]

        # Tìm các CVE chung và CVE mới
        common_cves = set(df_normal['CVE']).intersection(
            set(df_malware['CVE']))
        new_cves = set(df_malware['CVE']) - set(df_normal['CVE'])
        resolved_cves = set(df_normal['CVE']) - set(df_malware['CVE'])

        output = ["--- Nessus CVE Comparison ---"]

        if not common_cves and not new_cves and not resolved_cves:
            output.append("Không tìm thấy CVE nào hợp lệ trong hai file.")
            return "\n".join(output)

        # Danh sách các thuộc tính quan trọng để so sánh
        key_attributes = [
            'Plugin ID', 'Risk', 'CVSS v3.0 Base Score', 'Port', 'Name',
            'Solution', 'Plugin Output'
        ]

        # Xử lý các CVE chung
        if common_cves:
            output.append(
                f"Tìm thấy {len(common_cves)} CVE giống nhau giữa hai hệ thống:")
            for cve in sorted(common_cves):
                output.append(f"\nCVE: {cve}")
                normal_rows = df_normal[df_normal['CVE'] == cve]
                malware_rows = df_malware[df_malware['CVE'] == cve]

                # So sánh từng dòng của malware_rows với normal_rows
                for _, malware_row in malware_rows.iterrows():
                    normal_row = normal_rows[normal_rows['Plugin ID']
                                             == malware_row['Plugin ID']]
                    if not normal_row.empty:
                        normal_row = normal_row.iloc[0]
                        differences = []

                        # So sánh các thuộc tính quan trọng
                        for attr in key_attributes:
                            malware_value = str(
                                malware_row.get(attr, 'N/A')).strip()
                            normal_value = str(
                                normal_row.get(attr, 'N/A')).strip()
                            if malware_value != normal_value:
                                differences.append(
                                    f"{attr}: {normal_value} → {malware_value}"
                                )

                        # Nếu không có sự khác biệt, chỉ hiển thị thông tin từ hệ thống normal
                        if not differences:
                            for attr in key_attributes:
                                value = str(normal_row.get(
                                    attr, 'N/A')).strip()
                                output.append(f"{attr}: {value}")
                        else:
                            # Nếu có sự khác biệt, hiển thị thông tin từ cả hai hệ thống
                            output.append(
                                "--- Thông tin từ hệ thống bình thường ---")
                            for attr in key_attributes:
                                value = str(normal_row.get(
                                    attr, 'N/A')).strip()
                                output.append(f"{attr}: {value}")
                            output.append(
                                "--- Thông tin từ hệ thống bị nhiễm ---")
                            for attr in key_attributes:
                                value = str(malware_row.get(
                                    attr, 'N/A')).strip()
                                output.append(f"{attr}: {value}")
                            output.append("--- Sự khác biệt ---")
                            output.extend(differences)

        # Xử lý các CVE mới trong file malware
        if new_cves:
            output.append("\nCVE mới trong hệ thống bị nhiễm:")
            for cve in sorted(new_cves):
                output.append(f"\n--CVE mới--")
                output.append(f"CVE: {cve}")
                for _, row in df_malware[df_malware['CVE'] == cve].iterrows():
                    output.append("--- Thông tin chi tiết ---")
                    for attr in key_attributes:
                        value = str(row.get(attr, 'N/A')).strip()
                        output.append(f"{attr}: {value}")

        # Xử lý các CVE đã được khắc phục
        if resolved_cves:
            output.append("\nCVE đã được khắc phục trong hệ thống bị nhiễm:")
            for cve in sorted(resolved_cves):
                output.append(f"\nCVE: {cve}")
                for _, row in df_normal[df_normal['CVE'] == cve].iterrows():
                    output.append("--- Thông tin chi tiết ---")
                    for attr in key_attributes:
                        value = str(row.get(attr, 'N/A')).strip()
                        output.append(f"{attr}: {value}")

        return "\n".join(output)

    except Exception as e:
        return f"Error reading Nessus files: {str(e)}"


def main(cuckoo_file, virustotal_file, normal_nessus_file, malware_nessus_file, output_file="remediationa205.txt"):
    if os.path.exists(output_file):
        os.remove(output_file)  # clear previous content

    # 1. Cuckoo
    cuckoo_summary = read_cuckoo(cuckoo_file)
    write_to_file(cuckoo_summary, output_file)

    # 2. VirusTotal (đọc JSON trước)
    with open(virustotal_file, 'r', encoding='utf-8') as f:
        vt_json = json.load(f)
    vt_summary = read_virustotal(vt_json)
    write_to_file(vt_summary, output_file)

    # 3. Nessus
    nessus_summary = read_nessus(normal_nessus_file, malware_nessus_file)
    write_to_file(nessus_summary, output_file)


if __name__ == "__main__":
    data_dir = "data"
    main(os.path.join(data_dir, "cuckoo_a205.json"),
         os.path.join(data_dir, "vt_a205.json"),
         os.path.join(data_dir, "Test_1_normal_1.csv"),
         os.path.join(data_dir, "Test_1_a205b3000e64821c7d482e1b5c0fde9cedbbdc4783ba25d6019a93b325aa8742.csv"))
